import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRouteModule } from './app.route/app.route.module';
import { ProductsModule } from './products/products.module';
import { NewsModule } from './news/news.module';
import { SharedModlueModule } from './shared/shared-modlue.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgxSpinnerModule } from "ngx-spinner";
import { MyHttpInterceptor } from "./myHttpInters";


import { AppComponent } from './app.component';
import { SimpledirDirective } from './simpledir.directive';

@NgModule({
  declarations: [
    AppComponent,
    SimpledirDirective
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    NgxSpinnerModule,
    AppRouteModule,
    ProductsModule,
    NewsModule,
    SharedModlueModule
  ],
  providers: [ {
    provide: HTTP_INTERCEPTORS,
    useClass: MyHttpInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
