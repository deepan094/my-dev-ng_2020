import { Component, OnInit, Input, Output,EventEmitter, HostBinding, SimpleChanges } from '@angular/core';
// import { EventEmitter } from 'events';

@Component({
  selector: 'app-child-com1',
  templateUrl: './child-com1.component.html',
  styleUrls: ['./child-com1.component.css']
})
export class ChildCom1Component implements OnInit {
  msg = 'hello boss';
  @Input() getdata;
  @Output() datasend = new EventEmitter();

  
  @Input() title: String;
  @Output() titleChange = new EventEmitter();

  constructor() {

   }
  onclickme(){
    this.datasend.emit(this.msg);    
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log(changes);
  }
  ngDoCheck(){
    console.log("DO CHECK")
  }
  // @HostBinding('style.color') 'red';

  ngOnInit() {
  
    setTimeout(() => {
      this.titleChange.emit('vd boss');
    }, 4000);
        
  }

}
