import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class SharedServiceService {

  constructor(private _http:HttpClient) { }

  fetchData(url){
    return this._http.get(url);
  }
}
