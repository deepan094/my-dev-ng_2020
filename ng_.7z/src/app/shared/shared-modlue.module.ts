import { NgModule } from '@angular/core';
// import { HttpModule } from '@angular/http';
import { CommonModule } from '@angular/common';
import { SharedServiceService } from './shared-service.service'

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [SharedServiceService]
})
export class SharedModlueModule { }
