import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes,RouterModule, PreloadAllModules } from '@angular/router';
import { HomeComponent } from '../home/home.component';

export const route:Routes = [
    {
        path:'',
        redirectTo : 'home',
        pathMatch : 'full'
    },
    {
        path:'home',
        component : HomeComponent
    },
    {
      path:'lazyEmployees',
      loadChildren : '../employees/employees.module#EmployeesModule'
    }
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(route)//,{ preloadingStrategy: PreloadAllModules })
  ],
  exports:[
    RouterModule
  ],
  declarations: [
    HomeComponent
  ]
})
export class AppRouteModule { }
