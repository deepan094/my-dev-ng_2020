import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, CanLoad, Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { SharedServiceService } from '../shared/shared-service.service'

@Injectable()
export class GuardstestGuard implements CanActivate,Resolve<any> {
  constructor(private _SharedServiceService:SharedServiceService){}
  resolve(){
    return {'name':'vd'}
  }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      // alert("You don't have persmission ! contact VD ...");
    return true;
  }
}
