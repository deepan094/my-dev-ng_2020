import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GuardstestGuard } from '../app.route/guardstest.guard'
import { NewsRoutingModule } from './news-routing.module';
import { NewsListComponent } from './news-list/news-list.component';

@NgModule({
  imports: [
    CommonModule,
    NewsRoutingModule
  ],
  providers:[GuardstestGuard],
  declarations: [NewsListComponent]
})
export class NewsModule { }
