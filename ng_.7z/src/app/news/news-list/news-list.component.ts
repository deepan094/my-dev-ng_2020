import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-news-list',
  templateUrl: './news-list.component.html',
  styleUrls: ['./news-list.component.css']
})
export class NewsListComponent implements OnInit {

  constructor(private _ActivatedRoute:ActivatedRoute) { }

  ngOnInit() {
    console.log(this._ActivatedRoute.snapshot.data['news']);
  }

}
