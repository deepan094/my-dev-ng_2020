import { finalize, tap } from 'rxjs/operators';
import { HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
// import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class MyHttpInterceptor implements HttpInterceptor{
    count = 0;
    constructor(private spinner: NgxSpinnerService) { }
    intercept(req: HttpRequest<any>, next: HttpHandler) {
        this.spinner.show()
        this.count++;
        return next.handle(req)
            .pipe ( tap (
                    event => console.log(event),
                    error => console.log( error )
                ), finalize(() => {
                    this.count--;
                    if ( this.count == 0 ) this.spinner.hide ()
                })
            );
    }
}