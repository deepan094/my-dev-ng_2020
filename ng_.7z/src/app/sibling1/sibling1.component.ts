import { Component, OnInit, ContentChild } from '@angular/core';
import { CommonserviceService } from '../commonservice.service';
import { Sibling2Component } from '../sibling2/sibling2.component';


@Component({
  selector: 'app-sibling1',
  templateUrl: './sibling1.component.html',
  styleUrls: ['./sibling1.component.css']
})
export class Sibling1Component implements OnInit {
  x: string;

  @ContentChild(Sibling2Component) contentch;

  ngAfterContentInit(){
    console.log(this.contentch);
  }

  constructor(private _CommonserviceService:CommonserviceService) { }
  getval(){
    this._CommonserviceService.passdata('testing');
    this._CommonserviceService.$set('happy new year');
  }
  ngOnInit() {
    this.x = 'trisha'
  }

}
