import { Component, ViewChild, HostBinding, ViewChildren, QueryList, ContentChild, ElementRef, Renderer2 } from '@angular/core';
// import { GuardstestGuard } from './app.route/guardstest.guard'
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'App';
  obj = {'name':'vd','god':'insha allah'};
  
 constructor(private spinner:NgxSpinnerService){
   
  
 }
 ngOnInit() {
}
}
