import { Component, ViewChild, HostBinding, ViewChildren, QueryList, ContentChild, ElementRef, Renderer2 } from '@angular/core';
import { ChildCom1Component } from './child-com1/child-com1.component';
import { Sibling1Component } from './sibling1/sibling1.component';


// @Component({ selector:'emc', template:''})
// export class ChildCo { name = 'vj' }

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  obj = {'name':'vd','god':'insha allah'};
  
 constructor(private render2:Renderer2){
  //  debugger;
  //   console.log(elref);
 }
// childone
  @ViewChild(ChildCom1Component) childdatas;
  // @ViewChild('childone') childdatasEl : ElementRef;
  @ViewChild('childone', {read: ElementRef}) childdatasEl: ElementRef
  @ViewChildren(Sibling1Component) childrens :QueryList<any>;
 
  // ngOnInit() { 
  //   console.log(this.contentch)
  // }
  ngAfterViewInit(){
    
  // setTimeout(() => {
  //   this.title = 'vd boss 1';
  // }, 8000);
 
    // debugger;
    console.log(this.childdatasEl);
    this.render2.setStyle(this.childdatasEl.nativeElement,'color','tomato');
    console.log(this.childdatas);
    console.log(this.childrens.toArray());
    // setTimeout(() => { this.obj = {'name':'vd new','god':'786'};}, 5000);   
    setTimeout(() => { this.obj.name = 'baba' }, 5000);   
    // console.log(this.contentch);
    setTimeout(() => { this.childdatas.msg='hello god'; }, 0);
    
  }
  
  catch(e){
    alert(e);
  }
}
