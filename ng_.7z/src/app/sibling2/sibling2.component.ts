import { Component, OnInit } from '@angular/core';
import { CommonserviceService } from '../commonservice.service';

@Component({
  selector: 'app-sibling2',
  templateUrl: './sibling2.component.html',
  styleUrls: ['./sibling2.component.css']
})
export class Sibling2Component implements OnInit {
  local:any = 'default';
  constructor(private _CommonserviceService:CommonserviceService) { 
   
  }
  getmyval(){
   alert(this._CommonserviceService.$get());
  }
  ngOnInit() {
    this._CommonserviceService.missionAsObs.subscribe(function(val){
      this.local = val;
  });
  }

}
