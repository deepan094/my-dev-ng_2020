import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class CommonserviceService {

  constructor() { }
  private mission = new Subject();

  missionAsObs = this.mission.asObservable();

  passdata(item){
    this.mission.next(item);
  }
  datame:any;
  $set(va){
    this.datame = va;
  }
  $get(){
    return this.datame;
  }
}
