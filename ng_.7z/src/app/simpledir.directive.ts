import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appSimpledir]'
})
export class SimpledirDirective {

  @HostBinding('style.color') color = 'blue';
  @HostListener('click') myClick(){ 
    alert('HostListener');
    this.color = 'red';
  }
  // @HostBinding('attr.class') cssClass = 'alfa';

  constructor(){
    // this.colr = 'red';
  }


}
