import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from './product-list/product-list.component';
import { productsRoutingModule } from './products-routing.module';
import { ProductdetailsComponent } from './productdetails/productdetails.component'
import { ProductServiceService } from './product-service.service'

@NgModule({
  imports: [
    CommonModule,
    productsRoutingModule
  ],
  providers:[ProductServiceService],
  declarations: [ProductListComponent, ProductdetailsComponent]
})
export class ProductsModule { }
