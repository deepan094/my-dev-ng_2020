import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from '../products/product-list/product-list.component'
import { ProductdetailsComponent } from '../products/productdetails/productdetails.component'


const routes: Routes = [
  {
    path:'products',
    component: ProductListComponent,
    children:[
      {
        path:'productdetails',
        component: ProductdetailsComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class productsRoutingModule { }
