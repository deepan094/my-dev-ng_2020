import { switchMap } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , Params, ParamMap} from '@angular/router'
import { ProductServiceService } from '../product-service.service' 


@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {
  data: boolean;

  constructor( private _ProductServiceService:ProductServiceService) { }

  ngOnInit() {
      this._ProductServiceService.subj.subscribe((da)=>{
        this.data = da;
        // this.santizethis.sanitizer.bypassSecurityTrustUrl(this.url);
       
      });
  }
  ngDo

}
