import { Component, OnInit } from '@angular/core';
import { SharedServiceService } from '../../shared/shared-service.service'
import { ProductServiceService } from '../product-service.service' 
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: any;


  setIndex(item) {
     this._ProductService.setData(item);
  }
  constructor(private _NgxSpinnerService:NgxSpinnerService, private _SharedServiceService:SharedServiceService,private _ProductService:ProductServiceService) { }
  
  identify(key,value){
    return value.id;
  }

  // passDt(i){
  //   this._ProductService.setData(i);
  // }

  ngOnInit() {
      // this._NgxSpinnerService.show();
      this._SharedServiceService.fetchData('https://jsonplaceholder.typicode.com/photos')
        .subscribe((data) => {
          this.products = data;
          // this._NgxSpinnerService.hide();
        });
  }

}
