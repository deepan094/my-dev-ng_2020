import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ProductServiceService {
  sub: any;

  constructor() { }
  public subj = new BehaviorSubject(true);
  setData(val){
    // this.sub = new Observable((obse)=>{
      this.subj.next(val)
    // });
  }
  getD(){
    return this.subj.asObservable;
  }
  // observ = this.sub.asObservable();
  

  

}
